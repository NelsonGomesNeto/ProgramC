#include <stdio.h>

int soma(int x, int y)
{
  return(x + y);
}

int main()
{
  int num1, num2; scanf("%d%d", &num1, &num2);
  printf("%d\n", soma(num1, num2);
  return(0);
}
