#include <stdio.h>
#include <stdlib.h>

char m[20][20], final[20][20]; int best = 9999;
int Y, X, conta = 0;

int contar()
{
	conta = 0;
	for (Y = 0; Y < 10; Y ++)
	{
		for (X = 0; X < 10; X ++)
		{
			//printf("%c", m[Y][X]);
			if (m[Y][X] == '#')
			{
				conta ++;
			}
		}	//printf("\n");
	}
	return(conta);
}

void save()
{
	if (contar() < best)
	{
		best = contar();
		for (Y = 0; Y < 10; Y ++)
		{
			for (X = 0; X < 10; X ++)
			{
				final[Y][X] = m[Y][X];
			}
		}
	}
}

void go(int i, int j)
{
	//printf("%d %d\n", i, j);
	m[i][j] = 'O';
	save();
	m[i][j] = '#';
	if (i - 2 >= 0 && j - 1 >= 0 && m[i - 2][j - 1] == '#')
	{
		m[i][j] = 'O';
		go(i - 2, j - 1);
		save();
		m[i][j] = '#';
	}
	if (i - 2 >= 0 && j + 1 < 10 && m[i - 2][j + 1] == '#')
	{
		m[i][j] = 'O';
		go(i - 2, j + 1);
		save();
		m[i][j] = '#';
	}
	if (i - 1 >= 0 && j - 2 >= 0 && m[i - 1][j - 2] == '#')
	{
		m[i][j] = 'O';
		go(i - 1, j - 2);
		save();
		m[i][j] = '#';
	}
	if (i - 1 >= 0 && j + 2 < 10 && m[i - 1][j + 2] == '#')
	{
		m[i][j] = 'O';
		go(i - 1, j + 2);
		save();
		m[i][j] = '#';
	}
	if (i + 1 < 10 && j - 2 >= 0 && m[i + 1][j - 2] == '#')
	{
		m[i][j] = 'O';
		go(i + 1, j - 2);
		save();
		m[i][j] = '#';
	}
	if (i + 1 < 10 && j + 2 < 10 && m[i + 1][j + 2] == '#')
	{
		m[i][j] = 'O';
		go(i + 1, j + 2);
		save();
		m[i][j] = '#';
	}
	if (i + 2 < 10 && j - 1 >= 0 && m[i + 2][j - 1] == '#')
	{
		m[i][j] = 'O';
		go(i + 2, j - 1);
		save();
		m[i][j] = '#';
	}
	if (i + 2 < 10 && j + 1 < 10 && m[i + 2][j + 1] == '#')
	{
		m[i][j] = 'O';
		go(i + 2, j + 1);
		save();
		m[i][j] = '#';
	}
}

int main()
{
	int pair, run = 1;
	while (scanf("%d", &pair) && pair != 0)
	{
		int begin, end;
		int i, j;
		for (i = 0; i < 10; i ++)
		{
			for (j = 0; j < 10; j ++)
			{
				m[i][j] = '-';
				final[i][j] = '-';
			}
		}
		int start;
		for (i = 0; i < pair; i ++)
		{
			scanf("%d %d", &begin, &end);
			if (i == 0)
			{
				start = begin;
			}
			for (j = begin; j < begin + end; j ++)
			{
				m[i][j] = '#';
				final[i][j] = '#';
			}
		}
		best = 9999;
		go(0, start);
		int conta = 0;
		for (Y = 0; Y < 10; Y ++)
		{
			for (X = 0; X < 10; X ++)
			{
				//printf("%c", final[Y][X]);
				if (final[Y][X] == '#')
				{
					conta ++;
				}
			}	//printf("\n");
		}
		if (conta != 1)
		{
			printf("Case %d, %d squares can not be reached.\n", run, conta);
		}
		else
		{
			printf("Case %d, %d square can not be reached.\n", run, conta);
		}
		run ++;
	}
	return(0);
}