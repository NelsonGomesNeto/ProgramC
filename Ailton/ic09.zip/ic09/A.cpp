#include <stdio.h>
#include <stdlib.h>

char m[10][10];
int Y, X;
char key[10] = "IEHOVA#";

void adv(int y, int x, int i)
{
	if (i == 7)
	{
		return;
	}
	if (y - 1 < Y && m[y - 1][x] == key[i])
	{
		if (key[i] == '#')
		{
			printf("forth\n");
		}
		else
		{
			printf("forth ");
		}
		m[y][x] = ' ';
		adv(y - 1, x, i + 1);
		return;
	}
	if (x + 1 < X && m[y][x + 1] == key[i])
	{
		if (key[i] == '#')
		{
			printf("right\n");
		}
		else
		{
			printf("right ");
		}
		m[y][x] = ' ';
		adv(y, x + 1, i + 1);
		return;
	}
	if (x - 1 >= 0 && m[y][x - 1] == key[i])
	{
		if (key[i] == '#')
		{
			printf("left\n");
		}
		else
		{
			printf("left ");
		}
		m[y][x] = ' ';
		adv(y, x - 1, i + 1);
		return;
	}
}

int main()
{
	int tests; scanf("%d", &tests);
	while (tests > 0)
	{
		scanf("%d %d", &Y, &X);
		int i, j, pI, pJ;
		for (i = 0; i < 10; i ++)
		{
			for (j = 0; j < 10; j ++)
			{
				m[i][j] = '\0';
			}
		}
		for (i = 0; i < Y; i ++)
		{
			getchar();
			for (j = 0; j < X; j ++)
			{
				scanf("%c", &m[i][j]);
				if (m[i][j] == '@')
				{
					pI = i; pJ = j;
				}
			}
		}
		adv(pI, pJ, 0);
		tests --;
	}
	return(0);
}