#include <stdio.h>

int main()
{
  int contador;
  for (contador = 50; contador >= 20; contador --)
  {
    printf("%d\n", contador);
  }
  return(0);
}
