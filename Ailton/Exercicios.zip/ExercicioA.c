#include <stdio.h>

int main()
{
  int n, contador = 0;
  scanf("%d", &n);
  n *= 2;
  while (contador < n)
  {
    printf("Eu adora programar\n");
    contador ++;
  }
  return(0);
}
