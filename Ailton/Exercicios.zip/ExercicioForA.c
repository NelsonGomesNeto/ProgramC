#include <stdio.h>

int main()
{
  int contador;
  for (contador = 20; contador <= 50; contador ++)
  {
    printf("%d\n", contador);
  }
  return(0);
}
