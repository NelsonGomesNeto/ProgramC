#include <stdio.h>

int main()
{
  int contador = 20;
  while (contador >= 1)
  {
    printf("%d\n", contador);
    contador --;
  }
  return(0);
}
