#ifndef __TYPES_H__
#define __TYPES_H__
typedef unsigned char u_char;
typedef unsigned long u_long;
#endif /* __TYPES_H__ */
